import React from 'react';

export default function EditorTag({tag}) {
    return(
        <li>
            {tag.name}
        </li>
    )
}