export const CLEAR_ERRORS = "CLEAR_ERRORS";

export function clearErrors() {
    return ({
        type: CLEAR_ERRORS
    });
}