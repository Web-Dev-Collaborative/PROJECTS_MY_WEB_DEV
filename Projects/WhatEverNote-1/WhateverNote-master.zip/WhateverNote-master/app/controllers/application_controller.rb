class ApplicationController < ActionController::Base

    protect_from_forgery with: :null_session #disable auth token

    helper_method :current_user, :logged_in?

    def current_user
        @current_user ||= User.find_by(session_token: session[:session_token])
    end

    def login!(user)
        @current_user = user
        session[:session_token] = user.session_token
    end

    def logged_in?
        !!current_user
    end

    def logout!
        if logged_in?
            @current_user.reset_session_token!
            session[:session_token] = nil
            @current_user = nil
        end
    end
end
